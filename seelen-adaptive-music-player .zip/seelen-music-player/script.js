class MusicPlayer {
  constructor() {
    this.isPlaying = false;
    this.playPauseBtn = document.querySelector('.play-pause');
    this.progressBar = document.querySelector('.progress-bar');
    
    this.playPauseBtn.addEventListener('click', () => this.togglePlayback());
    setInterval(() => this.updateProgress(), 1000);
  }
  
  togglePlayback() {
    this.isPlaying = !this.isPlaying;
    this.playPauseBtn.textContent = this.isPlaying ? '⏸' : '⏯';
  }
  
  updateProgress() {
    const progress = Math.random() * 100; // Simulated progress
    this.progressBar.style.width = `${progress}%`;
  }
}

window.onload = () => new MusicPlayer();